XLM-R / MuRIL Hindi-English study

All scores use the same 1,000 held-out Hindi-English phrase identities and labels, bound by the study's dataset and split hashes.

These are synthetic template results, not evidence of real-world emotion accuracy or generalization.

Combined XLM-R used 16,000 training phrases across two language mixes; MuRIL uses 8,000 Hindi-English phrases. This comparison does not isolate the encoder's effect.

Macro-F1 weights each of the seven emotions equally; accuracy counts the fraction of correctly classified phrases.

No statistical significance, latency, memory-use or human-labelled benchmark claim is made by this report.